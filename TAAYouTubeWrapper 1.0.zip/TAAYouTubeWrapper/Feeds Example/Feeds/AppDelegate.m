//
//  AppDelegate.m
//  Feeds
//
//  Created by Daniel Salber on 23/11/15.
//  Copyright © 2015 mackey.nl. All rights reserved.
//

#import "AppDelegate.h"
#import "DetailViewController.h"

@interface AppDelegate () <UISplitViewControllerDelegate>

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
