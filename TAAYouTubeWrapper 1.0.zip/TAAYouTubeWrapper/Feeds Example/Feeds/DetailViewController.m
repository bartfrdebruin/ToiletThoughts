//
//  DetailViewController.m
//  Feeds
//
//  Created by Daniel Salber on 23/11/15.
//  Copyright © 2015 mackey.nl. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

@end
