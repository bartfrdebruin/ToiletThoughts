//
//  MasterViewController.h
//  Feeds
//
//  Created by Daniel Salber on 23/11/15.
//  Copyright © 2015 mackey.nl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@end

