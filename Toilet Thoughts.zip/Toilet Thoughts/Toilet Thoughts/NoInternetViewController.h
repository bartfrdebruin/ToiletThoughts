//
//  NoInternetViewController.h
//  Toilet Thoughts
//
//  Created by Bart de Bruin on 16-12-15.
//  Copyright © 2015 BartandFouad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NoInternetViewController : UIViewController

@end
